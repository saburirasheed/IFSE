To reproduce results for Test Problem 1 run the file

Convergencetest_full