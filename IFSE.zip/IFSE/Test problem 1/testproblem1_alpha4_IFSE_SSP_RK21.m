%%  Solution to 2D Test 1 model problem with exact solution using IFSE scheme
% this algorithm uses RDP
% Ref: E.O Asante-Asamani
% 06/13/2023
% Saburi Rasheed 
% 4 December 2024

function [runtime,errorval] = testproblem1_alpha4_IFSE_SSP_RK21(dt,steps)
 
clc; close all;
% dt: time step
% steps: number of interior spatial points in each coordinate direction
 %dt= 0.1; steps =80;

%% Model Paramters and initial conditions

% diffusion coefficient
d = 1; 

%% create nodes
x = linspace(-0.5*pi,0.5*pi,steps+2);
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end


% discretize time interval
T = 1;
t = 0:dt:T; tlen = length(t);

% initial condition for w_old(continuous)
u_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 u_old(i) = cos(xn)*cos(yn);
end

%%  matrix Assembly
e = ones(steps,1); II = speye(nnodes);I = eye(steps);
A = (d/h^2)*spdiags([-e 2*e -e], -1:1, steps, steps); % finite difference diffusion operator
M1 = kron(I,A); % for x direction
M2 = kron(A,I);  % for y direction

A1 = sparse(II+(dt/3)*M1); A11 = sparse(II+(dt/4)*M1);
A2 = sparse(II+(dt/3)*M2); A22 = sparse(II+(dt/4)*M2);

%% Time Evolution
   
 [L1,U1] = lu(A1); [L11,U11] = lu(A11); 
 [L2,U2] = lu(A2); [L22,U22] = lu(A22); 



tic
for i = 1:tlen-1
       alpha_n = 1;
     upred_SSP =u_old + dt*0.5*(1-alpha_n)*N(u_old);
     u_sol1 = 0.5*u_old + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Integrating Factor Scheme
    % Stage 1
    a1= alpha_n*N(u_sol1);
    b1 = U2\(L2\(9*u_sol1));
    b2 = U22\(L22\(-8*u_sol1));
    c1 = b1 + b2;
    b3 = U2\(L2\(3*dt*a1));
    b4 = U22\(L22\(-2*dt*a1));
    c2 = b3 + b4;
    a2 = c1 + c2;
    b5 = U1\(L1\(9*a2));
    b6 = U11\(L11\(-8*a2));
    wTilde = b5 + b6;
     % Stage 2 
    a3 = alpha_n*N(wTilde);
    b7 = U1\(L1\(-9*a1));
    b8 = U11\(L11\(8*a1));
    c3 = b7 + b8;
    d1=a3 +c3;
    b9 = U2\(L2\(dt*d1));
    b10 = U22\(L22\(-0.5*dt*d1));
    c4 = b9 + b10;
    u_sol2 = wTilde + c4;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    upred_SSP =u_sol2 + dt*0.5*(1-alpha_n)*N(u_sol2);
    u_old = 0.5*u_sol2 + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end
runtime = toc;
%%
% Compute exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end

% Return maximum error
 errorval = max(abs((u_exact-u_old)));

% %% Plot numerical solution
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(u_old,steps,steps);
% y = x;
% figure(1)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% % 
% % Plot exact solution
% Uexact=zeros(steps+2);
% Uexact(2:steps+1,2:steps+1) = reshape(u_exact,steps,steps);
% y = x;
% figure(2)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar




%****************function calls**************************************
function Fr = N(u)
 Fr = -u;
end




end