% Experiment to compute rate of convergence of IFSE 
% in comparison with other second ETD schemes
% February 2026
% Saburi Tolulope Rasheed


clc;clear
% Time steps
%k1=0.125;k2=0.0625;k3=0.03125;k4=0.0156;k5 =0.0078;
%k1=0.125;k2=0.0625;k3=0.03125;k4=0.0156;k5 =0.0078;
%k1=0.0125;k2=0.00625;k3=0.003125;k4=0.00156;k5=0.00078;
%k1=0.025;k2=0.0125;k3=0.00625;k4=0.003125;k5=0.00156;
%k1=0.05;k2=0.025;k3=0.0125;k4=0.00625;k5=0.003125;
% k1=0.1;k2=0.05;k3=0.025;k4=0.0125;k5 =0.00625;
%k1=0.0025;k2=0.0025/2;k3=0.0025/4;k4=0.0025/8;k5 =0.0025/16;

% k1=0.05;k2=0.05/2;k3=0.05/4;k4=0.05/8;k5 =0.05/16;

% k1=0.025;k2=0.025/2;k3=0.025/4;k4=0.025/8;k5 =0.025/16;k6 =0.025/32;

k1=0.1;k2=0.1/2;k3=0.1/4;k4=0.1/8;k5 =0.1/16; k6=0.1/32;

% k1=0.05;k2=0.05/2;k3=0.05/4;k4=0.05/8;k5 =0.05/16; k6=0.05/32;

%  k1=0.01;k2=0.01/2;k3=0.01/4;k4=0.01/8;k5 =0.01/16;


% Mesh size
% h1=5; h2=10; h3=20; h4=40; h5= 80;h6= 160;
% h1=30; h2=60; h3=120; h4=240; h5= 480;h6=960;
  h1=24; h2=49; h3=99; h4=199; h5= 399;h6=799;
%h1=19; h2=39; h3=79; h4=159;
%h1=10 ;h2 = h1; h3 = h1; h4 = h1;


step = [k1,k2,k3,k4,k5];space=[h1,h2,h3,h4,h5];


%% results for  alpha = 0
[runtime1,error1] =  testproblem1_alpha1_IFSE_SSP_RK21(k1,h1);
[runtime2,error2] =  testproblem1_alpha1_IFSE_SSP_RK21(k2,h2);
[runtime3,error3] =  testproblem1_alpha1_IFSE_SSP_RK21(k3,h3);
[runtime4,error4] =  testproblem1_alpha1_IFSE_SSP_RK21(k4,h4);
[runtime5,error5] =  testproblem1_alpha1_IFSE_SSP_RK21(k5,h5);

Timealpha1IFSE=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convalpha1IFSE,erroralpha1IFSE]=convergence_test1(error1,error2,error3,error4,error5,step);

%% results for  alpha = 0.25
[runtime1,error1] =  testproblem1_alpha2_IFSE_SSP_RK21(k1,h1);
[runtime2,error2] =  testproblem1_alpha2_IFSE_SSP_RK21(k2,h2);
[runtime3,error3] =  testproblem1_alpha2_IFSE_SSP_RK21(k3,h3);
[runtime4,error4] =  testproblem1_alpha2_IFSE_SSP_RK21(k4,h4);
[runtime5,error5] =  testproblem1_alpha2_IFSE_SSP_RK21(k5,h5);

Timealpha2IFSE=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convalpha2IFSE,erroralpha2IFSE]=convergence_test1(error1,error2,error3,error4,error5,step);

%% results for  alpha = 0.5
[runtime1,error1] =  testproblem1_alpha3_IFSE_SSP_RK21(k1,h1);
[runtime2,error2] =  testproblem1_alpha3_IFSE_SSP_RK21(k2,h2);
[runtime3,error3] =  testproblem1_alpha3_IFSE_SSP_RK21(k3,h3);
[runtime4,error4] =  testproblem1_alpha3_IFSE_SSP_RK21(k4,h4);
[runtime5,error5] =  testproblem1_alpha3_IFSE_SSP_RK21(k5,h5);

Timealpha3IFSE=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convalpha3IFSE,erroralpha3IFSE]=convergence_test1(error1,error2,error3,error4,error5,step);

%% results for  alpha = 1
[runtime1,error1] =  testproblem1_alpha4_IFSE_SSP_RK21(k1,h1);
[runtime2,error2] =  testproblem1_alpha4_IFSE_SSP_RK21(k2,h2);
[runtime3,error3] =  testproblem1_alpha4_IFSE_SSP_RK21(k3,h3);
[runtime4,error4] =  testproblem1_alpha4_IFSE_SSP_RK21(k4,h4);
[runtime5,error5] =  testproblem1_alpha4_IFSE_SSP_RK21(k5,h5);

Timealpha4IFSE=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convalpha4IFSE,erroralpha4IFSE]=convergence_test1(error1,error2,error3,error4,error5,step);


%% results for ETDRDP-IF 
[runtime1,error1] = test1_ETDRDPIF1(k1,h1);
[runtime2,error2] = test1_ETDRDPIF1(k2,h2);
[runtime3,error3] = test1_ETDRDPIF1(k3,h3);
[runtime4,error4] = test1_ETDRDPIF1(k4,h4);
[runtime5,error5] = test1_ETDRDPIF1(k5,h5);


TimeRDPIF=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convRDPIF,errorRDPIF]=convergence_test1(error1,error2,error3,error4,error5,step);
% 
%% results for IMEX-BDF2 
[runtime1,error1] =testproblem1_IMEX_BDF2(k1,h1);
[runtime2,error2] =testproblem1_IMEX_BDF2(k2,h2);
[runtime3,error3] =testproblem1_IMEX_BDF2(k3,h3);
[runtime4,error4] =testproblem1_IMEX_BDF2(k4,h4);
[runtime5,error5] =testproblem1_IMEX_BDF2(k5,h5);

TimeIMEX=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIMEX,errorIMEX]=convergence_test1(error1,error2,error3,error4,error5,step);







%% Generate efficiency and convergence plots
 Time_mat = [Timealpha1IFSE;Timealpha2IFSE;Timealpha3IFSE;Timealpha4IFSE;TimeRDPIF;TimeIMEX];  % To generate the first figure in Test problem 1
 Error_mat = [erroralpha1IFSE;erroralpha2IFSE;erroralpha3IFSE;erroralpha4IFSE;errorRDPIF;errorIMEX];  % To generate the first figure in Test problem 1




 efficiency_plot_test1(Time_mat,Error_mat)
 convergence_plot_test1(step,Error_mat)


% Display results
fprintf(' Results for IFSE alpha = 0\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),(pi)/(space(i)+1),erroralpha1IFSE(i),convalpha1IFSE(i),Timealpha1IFSE(i))
end

fprintf(' Results for IFSE alpha = 0.25\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),(pi)/(space(i)+1),erroralpha2IFSE(i),convalpha2IFSE(i),Timealpha2IFSE(i))
end
fprintf(' Results for IFSE alpha = 0.5\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),(pi)/(space(i)+1),erroralpha3IFSE(i),convalpha3IFSE(i),Timealpha3IFSE(i))
end
fprintf(' Results for IFSE alpha = 1\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),(pi)/(space(i)+1),erroralpha4IFSE(i),convalpha4IFSE(i),Timealpha4IFSE(i))
end
fprintf(' Results for ETDRDPIF\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),(pi)/(space(i)+1),errorRDPIF(i),convRDPIF(i),TimeRDPIF(i))
end
fprintf(' Results for IMEX-BDF2\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/(space(i)+1),errorIMEX(i),convIMEX(i),TimeIMEX(i))
end


