% function to compute error and convergence rates

function [conv,errorvec]=convergence_test1(error1,error2,error3,error4,error5,step)

 
%initialize variables
errorvec = [error1, error2,error3,error4,error5]; 
conv = zeros(5,1);

%calculate rate of convergence
conv(1)=0;
for i = 2:5
    conv(i) = (log(errorvec(i-1)/errorvec(i)))/(log(step(i-1)/step(i)));
end
