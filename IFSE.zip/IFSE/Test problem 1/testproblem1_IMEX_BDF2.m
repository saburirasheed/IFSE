%%  Solution to 2D Test 1 model problem with exact solution using IMEX-BDF2 scheme
% this algorithm uses RDP
% Ref: E.O Asante-Asamani
% 06/13/2023
% Saburi Rasheed 
% 4 December 2024

function [runtime,errorval] = testproblem1_IMEX_BDF2(dt,steps)
 
clc; close all;
% dt: time step
% steps: number of interior spatial points in each coordinate direction
%   dt = 0.05; steps = 39;
%% Model Paramters and initial conditions

% diffusion coefficient
d = 1; 

% create nodes
x = linspace(-0.5*pi,0.5*pi,steps+2);
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end


% discretize time interval
T=1;
t = 0:dt:T; tlen = length(t);

% initial condition for u_old(continuous)
uold = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
uold(i) = cos(xn)*cos(yn);
end

%% Matrix Assembly with Homogeneous Dirichlet Boundary Conditions
e = ones(steps,1); Id = speye(nnodes); I = speye(steps);

% Finite difference diffusion operators with homogeneous Dirichlet BCs
% Note: steps should be nnodes - 2 if boundaries are excluded
As1 = (d/h^2)*spdiags([e -2*e e], -1:1, steps, steps); % x-direction
As2 = (d/h^2)*spdiags([e -2*e e], -1:1, steps, steps); % y-direction

% Create 2D operators (kron assumes the same discretization in x and y)
A1 = kron(I, As1); A2 = kron(As2, I); 
A = A1 + A2; 

% Implicit system matrices (no change needed here, as BCs are enforced via As1, As2)
M2 = sparse(3*Id - 2*dt*A); 
M3 = sparse(Id + 0.5*dt*A);
M4 = sparse(Id - 0.5*dt*A);

%% Time Evolution
%hw = waitbar(0,'Simulating...');
%tol = dt^3;
%tol=[tol,tol];
%parms=[40, 1, 0, 1, 1, 1]; % Uses Newtons method
%parms=[40, 1000, 0.5, 1, 1, 1]; % uses Modified Newtons methodEvolution


tic

[L4,U4] = lu(M4);[L2,U2] = lu(M2);

%Fully implicit Backward Euler step 
   %w_oldd = w_old;
  %[w_old1,~,~,~] = nsold(w_old,'fenzymebe2',tol,parms);
  
  %isequal(w_oldd,w_old)
  
% Semi implicit Backward Euler  
  %w_old1 = M1\(w_old + dt*F(w_old));
  
% IMEX-theta (0.5)
   uold1 = U4\(L4\(M3*uold + dt*F(uold))); 
    
% IMEX-TR as first step
%     F_old = F(w_old);
%     A_old = A*w_old;
%     w_star = A1\(w_old + dt*F_old + 0.5*dt*A_old);
%     F_star = F(w_star);
%     A_star = A*w_star;
%     % Full Scheme
%     w_old1 = w_old + 0.5*dt*(F_old+F_star) + 0.5*dt*(A_old +A_star);

for i = 3:tlen
    unew = U2\(L2\(4*uold1 -uold+4*dt*F(uold1)-2*dt*F(uold)));
    uold = uold1;
    uold1 = unew;       
end
runtime = toc;
usoln = unew;
%% Exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end

% Return maximum error
 errorval = max(abs((u_exact-usoln)));

% %% Plot numerical solution
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(usoln,steps,steps);
% y = x;
% figure(1)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% % 
% % Plot exact solution
% Uexact=zeros(steps+2);
% Uexact(2:steps+1,2:steps+1) = reshape(u_exact,steps,steps);
% y = x;
% figure(2)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar


%****************function calls**************************************
function Fr = F(u)
Fr = -u;
end





end