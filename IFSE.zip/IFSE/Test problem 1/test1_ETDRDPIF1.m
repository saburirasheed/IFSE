%% Solution to test problem 1 with exact solution using ETDRDPIF 
% this algorithm uses RDP
% Ref:E.O Asante-Asamani
% Saburi Rasheed
% 06/16/2024

function [runtime,errorval] = test1_ETDRDPIF1(dt,steps)
 
clc; close all;
% dt: time step
% steps: number of interior spatial points in each coordinate direction
% dt= 0.05; steps =40;

%% Model Paramters and initial conditions

% diffusion coefficient
d = 1; 

% create nodes
x = linspace(-0.5*pi,0.5*pi,steps+2);
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end


% discretize time interval
T = 1;
t = 0:dt:T; tlen = length(t);

% initial condition for w_old(continuous)
w_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 w_old(i) = cos(xn)*cos(yn);
end
%w_old = ones(nnodes,1);

%%  matrix Assembly
e = ones(steps,1); II = speye(nnodes);I = eye(steps);
A = (d/h^2)*spdiags([-e 2*e -e], -1:1, steps, steps); % finite difference diffusion operator
A1 = kron(I,A);  % for x direction
A2 = kron(A,I);  % for y direction
M1 = sparse(II+dt*A1); M2 = sparse(II+(dt/3)*A1); M3 = sparse(II+(dt/4)*A1);
M11 = sparse(II+dt*A2); M22 = sparse(II+(dt/3)*A2); M33 = sparse(II+(dt/4)*A2);

%% Time Evolution
tic
[L1,U1]= lu(M1); [L2,U2]=lu(M2); [L3,U3]=lu(M3);
[L11,U11]=lu(M11); [L22,U22]=lu(M22); [L33,U33]=lu(M33);
for i = 2:tlen
   %  waitbar(i/(tlen),hw)     
     F_old = F(w_old);
     w_star = U11\(L11\(w_old + dt*F_old));
     w_star = U1\(L1\w_star);
     F_star = F(w_star);
     a_1 = U2\(L2\w_old);
     b_1 = U3\(L3\w_old);
     c_1 = 9*a_1 - 8*b_1;
     a_2 = U2\(L2\F_old);
     b_2 = U3\(L3\F_old);
     c_2 = 9*a_2-8*b_2;
     d_1 = U22\(L22\(9*c_1+2*dt*c_2 + dt*F_star));
     d_2 = U33\(L33\(-8*c_1-(3/2)*dt*c_2-(dt/2)*F_star));
     w_old = d_1+d_2;

% without lu
%      F_old = F(w_old);
%      w_star = M11\(w_old + dt*F_old);
%      w_star = M1\w_star;
%      F_star = F(w_star);
%      a_1 = M2\w_old;
%      b_1 = M3\w_old;
%      c_1 = 9*a_1 - 8*b_1;
%      a_2 = M2\F_old;
%      b_2 = M3\F_old;
%      c_2 = 9*a_2-8*b_2;
%      d_1 = M22\(9*c_1+2*dt*c_2 + dt*F_star);
%      d_2 = M33\(-8*c_1-(3/2)*dt*c_2-(dt/2)*F_star);
%      w_old = d_1+d_2; 

end
runtime = toc;
%%
% Compute exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end

% Return maximum error
 errorval = max(abs((u_exact-w_old)));

% %% Plot numerical solution
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(w_old,steps,steps);
% y = x;
% figure(1)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% % 
% % Plot exact solution
% Uexact=zeros(steps+2);
% Uexact(2:steps+1,2:steps+1) = reshape(u_exact,steps,steps);
% y = x;
% figure(2)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar





%****************function calls**************************************
function Fr = F(u)
 Fr = -u;
end


end