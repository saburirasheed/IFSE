clc;
rng(0);
rand(1,5)

rng(123);
rand(1,5)

rng(123)
rand()

rng(0)
rand()

