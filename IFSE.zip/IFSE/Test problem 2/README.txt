To reproduce results for 2D FitzHugh-Nagumo Model  run the file

ConvFullTest_FHN