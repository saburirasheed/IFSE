%% Solution to 2D FitzHugh-Nagumo model Using IFSE with alpha =0.25  
% Ref: E.O Asante-Asamani
% 05/08/2014
% Saburi Rasheed
% February 26, 2026

function [runtime,u_soln] = test2_2DFitzHugh_IFSE_alpha2(dt,steps)
  clc; close all

% dt: time step
% steps: number of spatial points in each coordinate direction
%  dt=0.00157; steps=101;
%% Model Paramters and initial conditions
  gamma = 11; beta = 0.1; sigma =2.25; rho =0; 




% diffusion coefficient
   delta_u= 1 ;  delta_v= 42.1887; 
% create nodes

x = linspace(0,pi,steps); h = abs(x(1)-x(2)); 
y = x;
nnodes = steps^2;
nodes = zeros(nnodes,2);
j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [x(i) y(k)];
            j = j+1;
        end
end
nb = 2*nnodes; % becuase we are solving a system of 2 RDE

% discretize time interval
t = 0:dt:10; tlen = length(t);

% % initial condition for u

%% Initial condition
% Set the random number generator seed
%rng(123);
rng(0);
% initial condition for u
u_e = 0;
u_old = u_e + 10^(-3) * rand();                
% initial condition for v
v_e = 0; 
v_old = v_e + 10^(-3) * rand();

% Stacking nodes for evolution
W_old = zeros(nb,1);
W_old(1:2:nb-1) = u_old; W_old(2:2:nb) = v_old; 

%% Block matrix Assembly
C = zeros(2);
C(1,1) = (delta_u*dt)/h^2;
C(2,2) = (delta_v*dt)/h^2;
Q = blktridiag(2,-1,-1,steps);
Q(1,2) = -2; Q(steps,steps-1) = -2; % Neumann BC
I = eye(steps);
M1 = kron(kron(I,Q),C);M2 = kron(kron(Q,I),C); 
II = speye(nb); 
A1 = sparse(II+(dt/3)*M1); A11 = sparse(II+(dt/4)*M1);
A2 = sparse(II+(dt/3)*M2); A22 = sparse(II+(dt/4)*M2);

%% Time Evolution
   
 [L1,U1] = lu(A1); [L11,U11] = lu(A11); 
 [L2,U2] = lu(A2); [L22,U22] = lu(A22); 



tic
for i = 1:tlen-1
       alpha_n = 0.25;
     upred_SSP =W_old + dt*0.5*(1-alpha_n)*N(W_old);
     u_sol1 = 0.5*W_old + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Integrating Factor Scheme
    % Stage 1
    a1= alpha_n*N(u_sol1);
    b1 = U2\(L2\(9*u_sol1));
    b2 = U22\(L22\(-8*u_sol1));
    c1 = b1 + b2;
    b3 = U2\(L2\(3*dt*a1));
    b4 = U22\(L22\(-2*dt*a1));
    c2 = b3 + b4;
    a2 = c1 + c2;
    b5 = U1\(L1\(9*a2));
    b6 = U11\(L11\(-8*a2));
    wTilde = b5 + b6;
     % Stage 2 
    a3 = alpha_n*N(wTilde);
    b7 = U1\(L1\(-9*a1));
    b8 = U11\(L11\(8*a1));
    c3 = b7 + b8;
    d1=a3 +c3;
    b9 = U2\(L2\(dt*d1));
    b10 = U22\(L22\(-0.5*dt*d1));
    c4 = b9 + b10;
    u_sol2 = wTilde + c4;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    upred_SSP =u_sol2 + dt*0.5*(1-alpha_n)*N(u_sol2);
    W_old = 0.5*u_sol2 + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end
u_soln = W_old(1:2:nb-1); 
v_soln = W_old(2:2:nb);
U = reshape(u_soln,steps,steps); V = reshape(v_soln,steps,steps);
runtime = toc;
%  %% Plots
% figure
% contourf(x,y,U', 100,'LineColor', 'none')
% 
%  title('\bf\fontsize{20} U solution ')
%  colorbar
% 
% figure
% contourf(x,y,V', 100,'LineColor', 'none')
%  title('\bf\fontsize{20} V solution ')
% colorbar
% 
% 


% %****************function calls**************************************
function Fr = N(U)
 Fr = zeros(nb,1);
 u = U(1:2:nb-1); v = U(2:2:nb);
 f1 = sigma*(-u.^3 + u - v);
 f2 = sigma*(gamma*(u-beta*v+ rho));
 Fr(1:2:nb-1) = f1; Fr(2:2:nb) = f2;
end




end