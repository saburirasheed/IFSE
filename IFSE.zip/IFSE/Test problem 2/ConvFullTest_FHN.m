% Convergence test for IFSE  for Model Test problem 2 FHN
% February 2026


clc;clear
% Initial parameters
%  k1=0.1;k2=0.05;k3=0.025;k4=0.0125;kref=0.00625;
%   k1=0.05;k2=0.025;k3=0.0125;k4=0.00625;kref=0.003125;
%  k1=0.025;k2=0.0125;k3=0.00625;k4=0.003125;kref=0.0015625;
%  k1=0.00625;k2=0.00625/2;k3=0.00625/4;k4=0.00625/8;kref=0.00625/16;
%  k1=0.0025;k2=0.0025/2;k3=0.0025/4;k4=0.0025/8;kref=0.0025/16;
%  k1=0.002;k2=0.002/2;k3=0.002/4;k4=0.002/8;kref=0.002/16;
%  k1=0.005;k2=0.005/2;k3=0.005/4;k4=0.005/8;kref=0.005/16; 
%  k1=0.00125;k2=0.00125/2;k3=0.00125/4;k4=0.00125/8;kref=0.00125/16;
%  k1=0.0125;k2=0.0125/2;k3=0.0125/4;k4=0.0125/8;kref=0.0125/16;
%  k1=0.00167;k2=0.00167/2;k3=0.00167/4;k4=0.00167/8;kref=0.00167/16; 
 k1=0.01;k2=0.01/2;k3=0.01/4;k4=0.01/8;k5=0.01/16;kref=0.01/32;
%  k1=0.005;k2=0.005/2;k3=0.005/4;k4=0.005/8;kref=0.005/16;
%   k1=0.1;k2=0.1/2;k3=0.1/4;k4=0.1/8;k5=0.1/16;kref=0.01/16;
%   k1=0.05;k2=0.05/2;k3=0.05/4;k4=0.05/8;k5=0.05/16;kref=0.05/32;
%    k1=0.025;k2=0.025/2;k3=0.025/4;k4=0.025/8;k5=0.025/16;kref=0.025/32;

% Spatial Mesh
% h1 = 5; h2 = 10; h3=20; h4=40;href =80 ;
 h1 = 51; h2 = h1; h3=h1; h4=h1;h5=h1;href = h1;
 step = [k1,k2,k3,k4,k5]; space=[h1-1,h2-1,h3-1,h4-1,h5-1];
 



 %% results for IFSE alpha =0
[runtime1,soln1] = test2_2DFitzHugh_IFSE_alpha1(k1,h1);
[runtime2,soln2] = test2_2DFitzHugh_IFSE_alpha1(k2,h2);
[runtime3,soln3] = test2_2DFitzHugh_IFSE_alpha1(k3,h3);
[runtime4,soln4] = test2_2DFitzHugh_IFSE_alpha1(k4,h4);
[runtime5,soln5] = test2_2DFitzHugh_IFSE_alpha1(k5,h5);
[~,soln6] = test2_2DFitzHugh_IFSE_alpha1(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5; solnref6=soln6;

 TimeIFSEa1=[runtime1,runtime2,runtime3,runtime4,runtime5];
 [convIFSEa1,errorIFSEa1]=conv_2D_FHN(soln1,soln2,soln3,soln4,soln5,solnref2,solnref3,solnref4,solnref5,solnref6,step);

 %% results for IFSE alpha =0.25
[runtime1,soln1] = test2_2DFitzHugh_IFSE_alpha2(k1,h1);
[runtime2,soln2] = test2_2DFitzHugh_IFSE_alpha2(k2,h2);
[runtime3,soln3] = test2_2DFitzHugh_IFSE_alpha2(k3,h3);
[runtime4,soln4] = test2_2DFitzHugh_IFSE_alpha2(k4,h4);
[runtime5,soln5] = test2_2DFitzHugh_IFSE_alpha2(k5,h5);
[~,soln6] = test2_2DFitzHugh_IFSE_alpha2(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5; solnref6=soln6;

 TimeIFSEa2=[runtime1,runtime2,runtime3,runtime4,runtime5];
 [convIFSEa2,errorIFSEa2]=conv_2D_FHN(soln1,soln2,soln3,soln4,soln5,solnref2,solnref3,solnref4,solnref5,solnref6,step);

%% results for IFSE alpha =0.5
[runtime1,soln1] = test2_2DFitzHugh_IFSE_alpha3(k1,h1);
[runtime2,soln2] = test2_2DFitzHugh_IFSE_alpha3(k2,h2);
[runtime3,soln3] = test2_2DFitzHugh_IFSE_alpha3(k3,h3);
[runtime4,soln4] = test2_2DFitzHugh_IFSE_alpha3(k4,h4);
[runtime5,soln5] = test2_2DFitzHugh_IFSE_alpha3(k5,h5);
[~,soln6] = test2_2DFitzHugh_IFSE_alpha3(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5; solnref6=soln6;

 TimeIFSEa3=[runtime1,runtime2,runtime3,runtime4,runtime5];
 [convIFSEa3,errorIFSEa3]=conv_2D_FHN(soln1,soln2,soln3,soln4,soln5,solnref2,solnref3,solnref4,solnref5,solnref6,step);

 %% results for IFSE alpha =1
[runtime1,soln1] = test2_2DFitzHugh_IFSE_alpha4(k1,h1);
[runtime2,soln2] = test2_2DFitzHugh_IFSE_alpha4(k2,h2);
[runtime3,soln3] = test2_2DFitzHugh_IFSE_alpha4(k3,h3);
[runtime4,soln4] = test2_2DFitzHugh_IFSE_alpha4(k4,h4);
[runtime5,soln5] = test2_2DFitzHugh_IFSE_alpha4(k5,h5);
[~,soln6] = test2_2DFitzHugh_IFSE_alpha4(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5; solnref6=soln6;

 TimeIFSEa4=[runtime1,runtime2,runtime3,runtime4,runtime5];
 [convIFSEa4,errorIFSEa4]=conv_2D_FHN(soln1,soln2,soln3,soln4,soln5,solnref2,solnref3,solnref4,solnref5,solnref6,step);

%% results for ETDRDPIF
[runtime1,soln1] = test2_ETDRDPIF_2DFHN(k1,h1);
[runtime2,soln2] = test2_ETDRDPIF_2DFHN(k2,h2);
[runtime3,soln3] = test2_ETDRDPIF_2DFHN(k3,h3);
[runtime4,soln4] = test2_ETDRDPIF_2DFHN(k4,h4);
[runtime5,soln5] = test2_ETDRDPIF_2DFHN(k5,h5);
[~,soln6] = test2_ETDRDPIF_2DFHN(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5; solnref6=soln6;

TimeRDPIFT2=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convRDPIFT2,errorRDPIFT2]=conv_2D_FHN(soln1,soln2,soln3,soln4,soln5,solnref2,solnref3,solnref4,solnref5,solnref6,step);


%% results for IMEX-BDF2
[runtime1,soln1] = test2_IMEX_BDF2_2D_FHN(k1,h1);
[runtime2,soln2] = test2_IMEX_BDF2_2D_FHN(k2,h2);
[runtime3,soln3] = test2_IMEX_BDF2_2D_FHN(k3,h3);
[runtime4,soln4] = test2_IMEX_BDF2_2D_FHN(k4,h4);
[runtime5,soln5] = test2_IMEX_BDF2_2D_FHN(k5,h5);
[~,soln6] =   test2_IMEX_BDF2_2D_FHN(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5; solnref6=soln6;

TimeIMBDF2=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIMBDF2,errorIMBDF2]=conv_2D_FHN(soln1,soln2,soln3,soln4,soln5,solnref2,solnref3,solnref4,solnref5,solnref6,step);






 %% Effiency plot
 
 % Comparison for ETD Schemes

      Time_mat = [TimeIFSEa1;TimeIFSEa2;TimeIFSEa3;TimeIFSEa4;TimeRDPIFT2;TimeIMBDF2];
      Error_mat = [errorIFSEa1;errorIFSEa2;errorIFSEa3;errorIFSEa4;errorRDPIFT2;errorIMBDF2];

 efficiency_plot_2DFHN(Time_mat,Error_mat)
 convergence_plot_2DFHN(step,Error_mat)
 

%% Display results

fprintf(' Results IFSE with alpha = 0 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorIFSEa1(i),convIFSEa1(i),TimeIFSEa1(i))
end

fprintf(' Results IFSE with alpha = 0.25 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorIFSEa2(i),convIFSEa2(i),TimeIFSEa2(i))
end

fprintf(' Results IFSE with alpha = 0.5 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorIFSEa3(i),convIFSEa3(i),TimeIFSEa3(i))
end

fprintf(' Results IFSE with alpha = 1 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorIFSEa4(i),convIFSEa4(i),TimeIFSEa4(i))
end


fprintf(' Results ETDRDPIF \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRDPIFT2(i),convRDPIFT2(i),TimeRDPIFT2(i))
end

fprintf(' Results IMEX-BDF2 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorIMBDF2(i),convIMBDF2(i),TimeIMBDF2(i))
end


