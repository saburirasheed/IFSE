%%  Solution to 2D Enzyme kinetic problem  with IFSE scheme alpha =0.25
% this algorithm uses RDP
% Ref: E.O Asante-Asamani
% 06/13/2023
% Saburi Rasheed 
% 28 February 2026

function [runtime,u_old] = test3_2DEnzyme_IFSE_alpha2(dt,steps)
 
clc; close all;
% dt: time step
% steps: number of spatial points in each coordinate direction
%  dt=0.01; steps=38;
%% Model Paramters and initial conditions

% diffusion coefficient
d1 = 0.25; d2 = 0.25; 


% create nodes
nnodes = steps^2;
x = linspace(0,1,steps+2); y=x;
xint = x(2:steps+1); yint=xint;

h = abs(x(1)-x(2)); 
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end

% discretize time interval
t = 0:dt:1; tlen = length(t);

%% initial condition for w_old(continuous)
u_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 u_old(i) = sin(pi*xn)*sin(pi*yn);
end


%%  matrix Assembly
e = ones(steps,1); II = eye(nnodes);I = speye(steps);
As1 = (d1/h^2)*spdiags([-e 2*e -e], -1:1, steps, steps); % finite difference diffusion operator
As2 = (d2/h^2)*spdiags([-e 2*e -e], -1:1, steps, steps); % finite difference diffusion operator

M1 = kron(I,As1); M2 = kron(As2,I);  
A1 = sparse(II+(dt/3)*M1); A11 = sparse(II+(dt/4)*M1);
A2 = sparse(II+(dt/3)*M2); A22 = sparse(II+(dt/4)*M2);

%% Time Evolution
   
 [L1,U1] = lu(A1); [L11,U11] = lu(A11); 
 [L2,U2] = lu(A2); [L22,U22] = lu(A22); 



tic
for i = 1:tlen-1
       alpha_n = 0.25;
     upred_SSP =u_old + dt*0.5*(1-alpha_n)*N(u_old);
     u_sol1 = 0.5*u_old + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Integrating Factor ETDRDP-NV
     a1 = -(alpha_n)*N(u_sol1); a2 = 3*dt*(alpha_n)*N(u_sol1); a3 = -2*dt*(alpha_n)*N(u_sol1);

     % Stage 1
     b1 = U2\(L2\(u_sol1));
     b2 = U22\(L22\(u_sol1));
     c1 = 9*b1 - 8*b2;
     b3 = U2\(L2\(a2));
     b4 = U22\(L22\(a3));
     c2 = b3 + b4;
     d1 = c1 + c2;
     b5 = U1\(L1\(9*d1));
     b6 = U11\(L11\(-8*d1));
     uTilde = b5 + b6;
     % Stage 2 
     c3 = (alpha_n)*N(uTilde);
     b7 = U1\(L1\(9*a1));
     b8 = U11\(L11\(-8*a1));
     c4 = b7 + b8;
     d2 = c3 + c4;
     b9 = U2\(L2\(dt*d2));
     b10 = U22\(L22\(-0.5*dt*d2));
     c5 = b9 + b10;
     u_sol2 = uTilde + c5;
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    upred_SSP =u_sol2 + dt*0.5*(1-alpha_n)*N(u_sol2);
     u_old = 0.5*u_sol2 + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end
runtime = toc;
% %% Plots
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(u_old,steps,steps);
% figure
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} U solution ')
% colorbar



%****************function calls**************************************
function Fr = N(u)
 Fr = -u./(1+u);
end



end