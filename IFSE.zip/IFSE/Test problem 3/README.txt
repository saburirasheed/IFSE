To reproduce results for 2D Enzyme Kinematics Model  run the file

conv_fulltest_Enzyme