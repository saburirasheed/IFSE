% function to compute error and convergence rates

function [conv,error]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step)

% initialize variables
error = zeros(1,5);
conv  = zeros(1,5);
%  conv = error;

% Error 1
error(1) = max(abs(soln1 - soln2));

% Error 2
error(2) = max(abs(soln2 - soln3));

% Error 3
error(3) = max(abs(soln3 - soln4));

% Error 4
error(4) = max(abs(soln4 - soln5));

% Error 5
error(5) = max(abs(soln5 - soln6));

% convergence rates
conv(1) = 0;
for i = 2:5
    conv(i) = log(error(i-1)/error(i)) / log(step(i-1)/step(i));
end


