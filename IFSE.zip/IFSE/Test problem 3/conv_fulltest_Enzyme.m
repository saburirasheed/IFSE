% Experiment to compute rate of convergence of IFSE schemes in comparison with
% ETDRDPIF and IMEX-BDF2 second-order schemes for smooth enzyme kinetics 
% February 2026

clc;clear
% Time steps
%  k1=0.1;k2=0.05;k3=0.025;k4=0.0125;k5 =0.00625;
%  k1=0.05;k2=0.05/2;k3=0.05/4;k4=0.05/8;k5 =0.05/16;k6 =0.05/32;
  k1=0.1;k2=0.1/2;k3=0.1/4;k4=0.1/8;k5 =0.1/16;k6 =0.1/32;

% Mesh size
h1=99; h2=h1; h3=h1; h4=h1; h5=h1; h6=h1;

step = [k1,k2,k3,k4,k5];space=[h1,h2,h3,h4,h5];

%% results for IFSE alpha =0 
[runtime1,soln1] =  test3_2DEnzyme_IFSE_alpha1(k1,h1);
[runtime2,soln2] =  test3_2DEnzyme_IFSE_alpha1(k2,h2);
[runtime3,soln3] =  test3_2DEnzyme_IFSE_alpha1(k3,h3);
[runtime4,soln4] =  test3_2DEnzyme_IFSE_alpha1(k4,h4);
[runtime5,soln5] =  test3_2DEnzyme_IFSE_alpha1(k5,h5);
[runtime6,soln6] =  test3_2DEnzyme_IFSE_alpha1(k6,h6);

TimeIFSEalpha1=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIFSEalpha1,errorIFSEalpha1]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step);

%% results for IFSE alpha = 0.25 
[runtime1,soln1] =  test3_2DEnzyme_IFSE_alpha2(k1,h1);
[runtime2,soln2] =  test3_2DEnzyme_IFSE_alpha2(k2,h2);
[runtime3,soln3] =  test3_2DEnzyme_IFSE_alpha2(k3,h3);
[runtime4,soln4] =  test3_2DEnzyme_IFSE_alpha2(k4,h4);
[runtime5,soln5] =  test3_2DEnzyme_IFSE_alpha2(k5,h5);
[runtime6,soln6] =  test3_2DEnzyme_IFSE_alpha2(k6,h6);


TimeIFSEalpha2=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIFSEalpha2,errorIFSEalpha2]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step);

%% results for IFSE alpha = 0.5 
[runtime1,soln1] =  test3_2DEnzyme_IFSE_alpha3(k1,h1);
[runtime2,soln2] =  test3_2DEnzyme_IFSE_alpha3(k2,h2);
[runtime3,soln3] =  test3_2DEnzyme_IFSE_alpha3(k3,h3);
[runtime4,soln4] =  test3_2DEnzyme_IFSE_alpha3(k4,h4);
[runtime5,soln5] =  test3_2DEnzyme_IFSE_alpha3(k5,h5);
[runtime6,soln6] =  test3_2DEnzyme_IFSE_alpha3(k6,h6);

TimeIFSEalpha3=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIFSEalpha3,errorIFSEalpha3]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step);

%% results for IFSE alpha = 1 
[runtime1,soln1] =  test3_2DEnzyme_IFSE_alpha4(k1,h1);
[runtime2,soln2] =  test3_2DEnzyme_IFSE_alpha4(k2,h2);
[runtime3,soln3] =  test3_2DEnzyme_IFSE_alpha4(k3,h3);
[runtime4,soln4] =  test3_2DEnzyme_IFSE_alpha4(k4,h4);
[runtime5,soln5] =  test3_2DEnzyme_IFSE_alpha4(k5,h5);
[runtime6,soln6] =  test3_2DEnzyme_IFSE_alpha4(k6,h6);

TimeIFSEalpha4=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIFSEalpha4,errorIFSEalpha4]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step);

%% results for ETDRDPIF
[runtime1,soln1] = test3Enzyme_ETDRDPIF(k1,h1);
[runtime2,soln2] = test3Enzyme_ETDRDPIF(k2,h2);
[runtime3,soln3] = test3Enzyme_ETDRDPIF(k3,h3);
[runtime4,soln4] = test3Enzyme_ETDRDPIF(k4,h4);
[runtime5,soln5] = test3Enzyme_ETDRDPIF(k5,h5);
[runtime6,soln6] = test3Enzyme_ETDRDPIF(k6,h6);

TimeRDPIF=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convRDPIF,errorRDPIF]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step);

%% results for IMEX-BDF2 
[runtime1,soln1] = test3Enzyme_IMEX_BDF2(k1,h1);
[runtime2,soln2] = test3Enzyme_IMEX_BDF2(k2,h2);
[runtime3,soln3] = test3Enzyme_IMEX_BDF2(k3,h3);
[runtime4,soln4] = test3Enzyme_IMEX_BDF2(k4,h4);
[runtime5,soln5] = test3Enzyme_IMEX_BDF2(k5,h5);
[runtime6,soln6] = test3Enzyme_IMEX_BDF2(k6,h6);

TimeIBDF2=[runtime1,runtime2,runtime3,runtime4,runtime5];
[convIBDF2,errorIBDF2]=conv_ekinetics_finegrid1(soln1,soln2,soln3,soln4,soln5,soln6,step);


%% Produce Efficiency and Convergence plots 
%ETD Comparison
Time_mat = [TimeIFSEalpha1;TimeIFSEalpha2;TimeIFSEalpha3;TimeIFSEalpha4;TimeRDPIF;TimeIBDF2];
Error_mat = [errorIFSEalpha1;errorIFSEalpha2;errorIFSEalpha3;errorIFSEalpha4;errorRDPIF;errorIBDF2];

efficiency_plot_ekinetics(Time_mat,Error_mat)
convergenceplot_2Dekinetics(step,Error_mat)
%% Display results

fprintf(' Results for IFSE alpha = 0\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),1/(space(i)+1),errorIFSEalpha1(i),convIFSEalpha1(i),TimeIFSEalpha1(i))
end

fprintf(' Results for IFSE alpha = 0.25\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),1/(space(i)+1),errorIFSEalpha2(i),convIFSEalpha2(i),TimeIFSEalpha2(i))
end

fprintf(' Results for IFSE alpha = 0.5\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),1/(space(i)+1),errorIFSEalpha3(i),convIFSEalpha3(i),TimeIFSEalpha3(i))
end

fprintf(' Results for IFSE alpha = 1\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),1/(space(i)+1),errorIFSEalpha4(i),convIFSEalpha4(i),TimeIFSEalpha4(i))
end


fprintf(' Results for ETDRDPIF\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),1/(space(i)+1),errorRDPIF(i),convRDPIF(i),TimeRDPIF(i))
end

fprintf(' Results for IMEX-BDF2\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:5
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),1/(space(i)+1),errorIBDF2(i),convIBDF2(i),TimeIBDF2(i))
end

