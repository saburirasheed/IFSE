To reproduce results for 2D Prey-Predator Model   run the file

testproblem5_2D_PreyPredator_IFSE_alpha1

using parameters and final times T=150, 400, 1000, 2500, 5000, respectively.