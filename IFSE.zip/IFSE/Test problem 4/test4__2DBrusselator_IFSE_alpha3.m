%% Solution to 2D Brusselator model Using IFSE with alpha =0.5 
% Ref: E.O Asante-Asamani
% 05/08/2014
% Saburi Rasheed
% March 02, 2026

function [runtime,u_soln] = test4__2DBrusselator_IFSE_alpha3(dt,steps)
  clc;
% dt: time step (0.01)
% steps: number of spatial points in each coordinate direction (51)
%     dt =0.1; steps= 81;
%% Model Paramters and initial conditions
 A = 29.5; B = 17.42;

%  A = 3.4; B = 1; for Turing pattern

% diffusion coefficient
% mu = 2*10^(-5); 
mu = 0.002; 

% create nodes
x = linspace(0,1,steps); h = abs(x(1)-x(2)); 
y = x;
nnodes = steps^2;
nodes = zeros(nnodes,2);
j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [x(i) y(k)];
            j = j+1;
        end
end
nb = 2*nnodes; % becuase we are solving a system of 2 RDE

% discretize time interval
t = 0:dt:2; tlen = length(t);

% initial condition for u
u_old = 0.5 + nodes(:,2); 

% initial condition for v
v_old = 1 + 5*nodes(:,1); 

% Stacking nodes for evolution
W_old = zeros(nb,1);
W_old(1:2:nb-1) = u_old; W_old(2:2:nb) = v_old; 
%% Block matrix Assembly
C = zeros(2);
C(1,1) = (mu*dt)/h^2;
C(2,2) = (mu*dt)/h^2;
Q = blktridiag(2,-1,-1,steps);
Q(1,2) = -2; Q(steps,steps-1) = -2;  I = eye(steps);
M1 = kron(kron(I,Q),C);M2 = kron(kron(Q,I),C); 
II = speye(nb); 
A1 = sparse(II+(dt/3)*M1); A11 = sparse(II+(dt/4)*M1);
A2 = sparse(II+(dt/3)*M2); A22 = sparse(II+(dt/4)*M2);

%% Time Evolution
   
 [L1,U1] = lu(A1); [L11,U11] = lu(A11); 
 [L2,U2] = lu(A2); [L22,U22] = lu(A22); 



tic
for i = 1:tlen-1
       alpha_n = 0.5;
     upred_SSP =W_old + dt*0.5*(1-alpha_n)*N(W_old);
     u_sol1 = 0.5*W_old + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Integrating Factor Scheme
    % Stage 1
    a1= alpha_n*N(u_sol1);
    b1 = U2\(L2\(9*u_sol1));
    b2 = U22\(L22\(-8*u_sol1));
    c1 = b1 + b2;
    b3 = U2\(L2\(3*dt*a1));
    b4 = U22\(L22\(-2*dt*a1));
    c2 = b3 + b4;
    a2 = c1 + c2;
    b5 = U1\(L1\(9*a2));
    b6 = U11\(L11\(-8*a2));
    wTilde = b5 + b6;
     % Stage 2 
    a3 = alpha_n*N(wTilde);
    b7 = U1\(L1\(-9*a1));
    b8 = U11\(L11\(8*a1));
    c3 = b7 + b8;
    d1=a3 +c3;
    b9 = U2\(L2\(dt*d1));
    b10 = U22\(L22\(-0.5*dt*d1));
    c4 = b9 + b10;
    u_sol2 = wTilde + c4;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    upred_SSP =u_sol2 + dt*0.5*(1-alpha_n)*N(u_sol2);
    W_old = 0.5*u_sol2 + 0.5*(upred_SSP + dt*0.5*(1-alpha_n)*N(upred_SSP));
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
end
 u_soln = W_old(1:2:nb-1); 
 v_soln = W_old(2:2:nb);
 U = reshape(u_soln,steps,steps); V = reshape(v_soln,steps,steps);
runtime = toc;
 %% Plots
% figure
% contourf(x,y,U')
%  title('\bf\fontsize{20} U solution ')
%  colorbar
% 
% figure
% contourf(x,y,V')
%  title('\bf\fontsize{20} V solution ')
% colorbar




%****************function calls**************************************
function Fr = N(U)
 Fr = zeros(nb,1);
 u = U(1:2:nb-1); v = U(2:2:nb);
 f1 = B+u.^2.*v -(1+A)*u;
 f2 = A*u-u.^2.*v;
 Fr(1:2:nb-1) = f1; Fr(2:2:nb) = f2;
end






end