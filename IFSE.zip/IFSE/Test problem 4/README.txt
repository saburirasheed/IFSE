To reproduce results for 2D Brusselator Model  run the file

ConvergenceFullTest_Brusselator