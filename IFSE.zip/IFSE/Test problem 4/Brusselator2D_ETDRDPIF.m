%% Solution to 2D Brusselator model Using ETDRDPIF 
% Ref: E.O Asante-Asamani
% 05/08/2014
% Saburi Rasheed
% March 2026

function [runtime,u_soln] = Brusselator2D_ETDRDPIF(dt,steps)
 clc;
% dt: time step (0.01)
% steps: number of spatial points in each coordinate direction (51)
% dt = 0.1; steps = 41;
%% Model Paramters and initial conditions
% A = 29.5; B = 17.42;
% A = 29.5; B = 17.5;
 A = 3.4; B = 1;

% diffusion coefficient
mu_1 = 2.e-3; mu_2 = 2.e-3; 

% create nodes
x = linspace(0,1,steps); h = abs(x(1)-x(2)); 
y = linspace(0,1,steps);
nnodes = steps^2;
nodes = zeros(nnodes,2);
j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [x(i) y(k)];
            j = j+1;
        end
end
nb = 2*nnodes;

% discretize time interval
t = 0:dt:50; tlen = length(t);


% initial condition for u
u_old = 0.5 + nodes(:,2); 

% initial condition for v
v_old = 1 + 5*nodes(:,1); 

% Stacking nodes for evolution
W_old = zeros(nb,1);
W_old(1:2:nb-1) = u_old; W_old(2:2:nb) = v_old; 

%% Block matrix Assembly
C = zeros(2);
C(1,1) = (mu_1*dt)/h^2;
C(2,2) = (mu_2*dt)/h^2;
Q = blktridiag(2,-1,-1,steps);
Q(1,2) = -2; Q(steps,steps-1) = -2;  I = eye(steps);
M1 = kron(kron(I,Q),C);M2 = kron(kron(Q,I),C); 
II = speye(nb); 
A1 = sparse(II+ M1); A2 = sparse(II+(1/3)*M1); A3 = sparse(II+(1/4)*M1);
A11 = sparse(II+ M2); A22 = sparse(II+(1/3)*M2); A33 = sparse(II+(1/4)*M2);

%% Time Evolution
[L1,U1]= lu(A1); [L2,U2]=lu(A2); [L3,U3]=lu(A3);
[L11,U11]=lu(A11); [L22,U22]=lu(A22); [L33,U33]=lu(A33);
tic
for i = 2:tlen
   %  waitbar(i/(tlen),hw)     
     N_old = N(W_old);
     w_star = U11\(L11\(W_old + dt*N_old));
     w_star = U1\(L1\w_star);
     N_star = N(w_star);
     a_1 = U2\(L2\W_old);
     b_1 = U3\(L3\W_old);
     c_1 = 9*a_1 - 8*b_1;
     a_2 = U2\(L2\N_old);
     b_2 = U3\(L3\N_old);
     c_2 = 9*a_2-8*b_2;
     d_1 = U22\(L22\(9*c_1+2*dt*c_2 + dt*N_star));
     d_2 = U33\(L33\(-8*c_1-(3/2)*dt*c_2-(dt/2)*N_star));
     W_old = d_1+d_2;

% without lu
%      F_old = F(w_old);
%      w_star = M11\(w_old + dt*F_old);
%      w_star = M1\w_star;
%      F_star = F(w_star);
%      a_1 = M2\w_old;
%      b_1 = M3\w_old;
%      c_1 = 9*a_1 - 8*b_1;
%      a_2 = M2\F_old;
%      b_2 = M3\F_old;
%      c_2 = 9*a_2-8*b_2;
%      d_1 = M22\(9*c_1+2*dt*c_2 + dt*F_star);
%      d_2 = M33\(-8*c_1-(3/2)*dt*c_2-(dt/2)*F_star);
%      w_old = d_1+d_2; 

end
 u_soln = W_old(1:2:nb-1); 
 v_soln = W_old(2:2:nb);
 U = reshape(u_soln,steps,steps); V = reshape(v_soln,steps,steps);
runtime = toc;
 %% Plots
% % figure
% contourf(x,y,U')
%  title('\bf\fontsize{20} U solution ')
%  colorbar
% 
% figure
% contourf(x,y,V')
%  title('\bf\fontsize{20} V solution ')
% colorbar




%****************function calls**************************************
function Fr = N(U)
 Fr = zeros(nb,1);
 u = U(1:2:nb-1); v = U(2:2:nb);
 f1 = B+u.^2.*v -(A+1)*u;
 f2 = A*u-u.^2.*v;
 Fr(1:2:nb-1) = f1; Fr(2:2:nb) = f2;
end


end