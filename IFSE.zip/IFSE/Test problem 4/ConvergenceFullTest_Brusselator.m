% Convergence test for IFSE  for Model Test problem 2
% March 2025


clc;clear
% Initial parameters
% k1=0.1;k2=0.05;k3=0.025;k4=0.0125;kref=0.00625;
% k1=0.05;k2=0.025;k3=0.0125;k4=0.00625;kref=0.003125;
% k1=0.025;k2=0.0125;k3=0.00625;k4=0.003125;kref=0.0015625;
% k1=0.00125;k2=0.00125/2;k3=0.00125/4;k4=0.00125/8;kref=0.00125/16;
% k1=0.0025;k2=0.0025/2;k3=0.0025/4;k4=0.0025/8;kref=0.0025/16;
% k1=0.0025;k2=0.0025/2;k3=0.0025/4;k4=0.0025/8;kref=0.0025/16;
%  k1=0.005;k2=0.005/2;k3=0.005/4;k4=0.005/8;kref=0.005/16; 
% k1=0.00125;k2=0.00125/2;k3=0.00125/4;k4=0.00125/8;kref=0.00125/16;
% k1=0.0125;k2=0.0125/2;k3=0.0125/4;k4=0.0125/8;kref=0.0125/16;
% k1=0.00167;k2=0.00167/2;k3=0.00167/4;k4=0.00167/8;kref=0.00167/16; 
% k1=(0.00625);k2=(0.00625)/2;k3=(0.00625)/4;k4=(0.00625)/8;kref=(0.00625)/16;
k1=0.01;k2=0.01/2;k3=0.01/4;k4=0.01/8;kref=0.01/16;
 


% Spatial Mesh
%h1 = 5; h2 = 10; h3=20; h4=40;href =80 ;
h1 = 11; h2 = h1; h3=h1; h4=h1;href = h1;
 step = [k1,k2,k3,k4];
 space=[1/(h1-1),1/(h2-1),1/(h3-1),1/(h4-1),1/(href-1)];
 


 
 %% results for IFSE alpha =0
[runtime1,soln1] =  test4__2DBrusselator_IFSE_alpha1(k1,h1);
[runtime2,soln2] =  test4__2DBrusselator_IFSE_alpha1(k2,h2);
[runtime3,soln3] =  test4__2DBrusselator_IFSE_alpha1(k3,h3);
[runtime4,soln4] =  test4__2DBrusselator_IFSE_alpha1(k4,h4);
[~,soln5] =  test4__2DBrusselator_IFSE_alpha1(kref,href);



 TimeIFSEalpha1=[runtime1,runtime2,runtime3,runtime4];
 [convIFSEalpha1,errorIFSEalpha1]=conv_2D_Brusselator(soln1,soln2,soln3,soln4,soln5,step);

 %% results for IFSE alpha =0.25
[runtime1,soln1] = test4__2DBrusselator_IFSE_alpha2(k1,h1);
[runtime2,soln2] = test4__2DBrusselator_IFSE_alpha2(k2,h2);
[runtime3,soln3] = test4__2DBrusselator_IFSE_alpha2(k3,h3);
[runtime4,soln4] = test4__2DBrusselator_IFSE_alpha2(k4,h4);
[~,soln5] = test4__2DBrusselator_IFSE_alpha2(kref,href);



TimeIFSEalpha2=[runtime1,runtime2,runtime3,runtime4];
[convIFSEalpha2,errorIFSEalpha2]=conv_2D_Brusselator(soln1,soln2,soln3,soln4,soln5,step);
 
 %% results for IFSE alpha =0.5
[runtime1,soln1] = test4__2DBrusselator_IFSE_alpha3(k1,h1);
[runtime2,soln2] = test4__2DBrusselator_IFSE_alpha3(k2,h2);
[runtime3,soln3] = test4__2DBrusselator_IFSE_alpha3(k3,h3);
[runtime4,soln4] = test4__2DBrusselator_IFSE_alpha3(k4,h4);
[~,soln5] = test4__2DBrusselator_IFSE_alpha3(kref,href);



TimeIFSEalpha3=[runtime1,runtime2,runtime3,runtime4];
[convIFSEalpha3,errorIFSEalpha3]=conv_2D_Brusselator(soln1,soln2,soln3,soln4,soln5,step);


 %% results for IFSE alpha = 1
[runtime1,soln1] = test4__2DBrusselator_IFSE_alpha4(k1,h1);
[runtime2,soln2] = test4__2DBrusselator_IFSE_alpha4(k2,h2);
[runtime3,soln3] = test4__2DBrusselator_IFSE_alpha4(k3,h3);
[runtime4,soln4] = test4__2DBrusselator_IFSE_alpha4(k4,h4);
[~,soln5] = test4__2DBrusselator_IFSE_alpha4(kref,href);



TimeIFSEalpha4=[runtime1,runtime2,runtime3,runtime4];
[convIFSEalpha4,errorIFSEalpha4]=conv_2D_Brusselator(soln1,soln2,soln3,soln4,soln5,step);
 
 
 %% results for ETDRDPIF
[runtime1,soln1] = Brusselator2D_ETDRDPIF(k1,h1);
[runtime2,soln2] = Brusselator2D_ETDRDPIF(k2,h2);
[runtime3,soln3] = Brusselator2D_ETDRDPIF(k3,h3);
[runtime4,soln4] = Brusselator2D_ETDRDPIF(k4,h4);
[~,soln5] = Brusselator2D_ETDRDPIF(kref,href);


TimeETDRDPIF=[runtime1,runtime2,runtime3,runtime4];
[convETDRDPIF,errorETDRDPIF]=conv_2D_Brusselator(soln1,soln2,soln3,soln4,soln5,step);

 
 




%% Effiency plot
  
% Comparison for ETD Schemes
%  Time_mat = [TimeRDP;TimeIFSEalpha1;TimeIFSEalpha2;TimeIFSEalpha3;TimeIFSEalpha4;TimeP02];
%  Error_mat = [errorRDP;errorIFSEalpha1;errorIFSEalpha2;errorIFSEalpha3;errorIFSEalpha4;errorP02];

 Time_mat = [TimeETDRDPIF;TimeIFSEalpha1;TimeIFSEalpha2;TimeIFSEalpha3;TimeIFSEalpha4];
 Error_mat = [errorETDRDPIF;errorIFSEalpha1;errorIFSEalpha2;errorIFSEalpha3;errorIFSEalpha4];
 

%  efficiency_plot_2D_Brusselator(Time_mat,Error_mat)
%  convergence_plot_2D_Brusselator(step,Error_mat)
%  

%% Display results

fprintf(' Results IFSE with alpha = 0 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorIFSEalpha1(i),convIFSEalpha1(i),TimeIFSEalpha1(i))
end

fprintf(' Results IFSE with alpha = 0.25 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorIFSEalpha2(i),convIFSEalpha2(i),TimeIFSEalpha2(i))
end

fprintf(' Results IFSE with alpha = 0.5 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorIFSEalpha3(i),convIFSEalpha3(i),TimeIFSEalpha3(i))
end

fprintf(' Results IFSE with alpha = 1 \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorIFSEalpha4(i),convIFSEalpha4(i),TimeIFSEalpha4(i))
end

fprintf(' Results ETDRDPIF \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorETDRDPIF(i),convETDRDPIF(i),TimeETDRDPIF(i))
end



% fprintf(' Results ETDRDP \n')
% fprintf('k             h            error        conv       Time \n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorRDP(i),convRDP(i),TimeRDP(i))
% end
% 
% fprintf(' Results ETDPade02 \n')
% fprintf('k             h            error        conv       Time \n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorP02(i),convETDP02(i),TimeP02(i))
% end


% fprintf('Results BDF2 \n')
% fprintf('k             h            error        conv       Time \n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorBDF2(i),convBDF2(i),TimeBDF2(i))
% end




